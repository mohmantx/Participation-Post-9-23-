﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chuck_Norris_API
{
    class Quotes
    {
        public string value { get; set; }


        public override string ToString()
        {
            return value;
        }
    }

    
}
